<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(url('form')); ?>" method="POST">
        <input type="text" name="nama" placeholder="nama"/> <br> <br>
        <input type="email" name="email" placeholder="email"/> <br> <br>
        <?php echo csrf_field(); ?>
        <input type="submit"/>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\Project_Laravel\laravel\resources\views/form.blade.php ENDPATH**/ ?>